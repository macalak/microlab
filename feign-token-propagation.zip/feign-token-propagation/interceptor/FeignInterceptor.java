package com.parkdots.provisioninggtw.application.interceptor;


import com.parkdots.provisioninggtw.application.util.ThreadContext;
import org.springframework.stereotype.Component;

import feign.RequestInterceptor;
import feign.RequestTemplate;

@Component
public class FeignInterceptor implements RequestInterceptor {

	@Override
	public void apply(RequestTemplate template) {
		// token if present
		if (!"".equals(ThreadContext.getToken())) {
			template.header(ThreadContext.TOKEN_HEADER_ATTRIBUTE_NAME, 
					ThreadContext.TOKEN_HEADER_ATTRIBUTE_BEARER_PREFIX + ThreadContext.getToken());
		}
	}
}