package com.parkdots.provisioninggtw.application.interceptor;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;

@ControllerAdvice
public class ExceptionInterceptor {


		@ExceptionHandler(HttpClientErrorException.class)
		public ResponseEntity<String> handleCustomException(HttpClientErrorException ex) {

			ResponseEntity<String> response = new ResponseEntity<String>(ex.getResponseBodyAsString(), ex.getStatusCode());

			return response;
		}

		@ExceptionHandler(HttpServerErrorException.class)
		public ResponseEntity<String> handleCustomException(HttpServerErrorException ex) {

			ResponseEntity<String> response = new ResponseEntity<String>(ex.getResponseBodyAsString(), ex.getStatusCode());

			return response;
		}
}
