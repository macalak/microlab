
package com.parkdots.provisioninggtw.application.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class FeignClientConfiguration {

	@Bean
	public ClientErrorDecoder myErrorDecoder() {
	  return new ClientErrorDecoder();
	}
}
