package com.gopas.castleregister.domain.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import java.util.UUID;

@Entity
public class CastleRoute {
    private @Id UUID id;
    private String name;
    private String description;
    private Integer capacity;
    private OpeningHours openingHours;
    @ManyToOne
    @JoinColumn(name = "CASTLE_ID")
    private Castle castle;

    public CastleRoute() {
    }

    public CastleRoute(UUID id, String name, String description, Integer capacity, OpeningHours openingHours, Castle castle) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.capacity = capacity;
        this.openingHours = openingHours;
        this.castle = castle;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setCapacity(Integer capacity) {
        this.capacity = capacity;
    }

    public void setOpeningHours(OpeningHours openingHours) {
        this.openingHours = openingHours;
    }

    public void setCastle(Castle castle) {
        this.castle = castle;
    }

    public UUID getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public Integer getCapacity() {
        return capacity;
    }

    public OpeningHours getOpeningHours() {
        return openingHours;
    }

    public Castle getCastle() {
        return castle;
    }

    @Override
    public String toString() {
        return "CastleRoute{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", description='" + description + '\'' +
                ", capacity=" + capacity +
                ", openingHours=" + openingHours +
                ", castle=" + castle +
                '}';
    }
}
