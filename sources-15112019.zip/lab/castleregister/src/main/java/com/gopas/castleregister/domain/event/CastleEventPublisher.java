package com.gopas.castleregister.domain.event;

public interface CastleEventPublisher {
    void sendCastleCreatedEvent(CastleCreatedEvent event);
}
