package com.gopas.castleregister.domain.model;

import com.gopas.castleregister.domain.event.CastleCreatedEvent;
import com.gopas.castleregister.domain.event.CastleEventPublisher;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

@Entity
public class Castle {
    @Transient
    private final static Logger LOGGER = LoggerFactory.getLogger(Castle.class);

    @Id
    private UUID id;
    private String name;
    private String description;
    private CastleLocation castleLocation;
    @ManyToOne
    private CastleOwner currentOwner;
    @OneToMany(mappedBy = "castle")
    private Set<CastleRoute> castleRoutes = new HashSet<>();

    @Transient
    CastleRouteRepository castleRouteRepository;
    @Transient
    CastleRepository castleRepository;
    @Transient
    CastleEventPublisher castleEventPublisher;

    public Castle() {
    }

    public Castle(UUID id, String name, String description, CastleLocation castleLocation, CastleOwner currentOwner) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.castleLocation = castleLocation;
        this.currentOwner = currentOwner;
    }

    // Business logic
    public void addRoute(CastleRoute castleRoute){
        if(castleRoute != null){
            LOGGER.info("Adding Route {} to Castle {}", castleRoute, this);
            castleRoutes.add(castleRoute);
            castleRoute.setCastle(this);
            castleRouteRepository.createCastleRoute(castleRoute);
        }
    }

    // Business logic
    public void create(){
        LOGGER.info("Creating castle {}, to persistence", this);
        castleRepository.createCastle(this);
        castleEventPublisher.sendCastleCreatedEvent(createCastleCreatedEvent());
    }

    private CastleCreatedEvent createCastleCreatedEvent(){
        CastleCreatedEvent event = new CastleCreatedEvent();
        event.castleId = this.id.toString();
        event.description = this.description;
        event.latitude = this.castleLocation.getLatitude();
        event.longitude = this.castleLocation.getLongitude();
        event.name = this.name;
        event.ownerName = this.currentOwner.getName();
        return event;
    }

    public void setCastleRouteRepository(CastleRouteRepository castleRouteRepository) {
        this.castleRouteRepository = castleRouteRepository;
    }

    public void setCastleEventPublisher(CastleEventPublisher castleEventPublisher) {
        this.castleEventPublisher = castleEventPublisher;
    }

    public void setCastleRepository(CastleRepository castleRepository) {
        this.castleRepository = castleRepository;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setCastleLocation(CastleLocation castleLocation) {
        this.castleLocation = castleLocation;
    }

    public void setCurrentOwner(CastleOwner currentOwner) {
        this.currentOwner = currentOwner;
    }

    public UUID getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public CastleLocation getCastleLocation() {
        return castleLocation;
    }

    public CastleOwner getCurrentOwner() {
        return currentOwner;
    }

    public Set<CastleRoute> getCastleRoutes() {
        return castleRoutes;
    }

    @Override
    public String toString() {
        return "Castle{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", description='" + description + '\'' +
                ", castleLocation=" + castleLocation +
                ", currentOwner=" + currentOwner +
                ", castleRoutes=" + castleRoutes +
                '}';
    }
}
