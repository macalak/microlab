package com.gopas.castleregister.domain.model;

import java.util.UUID;

public interface CastleOwnerRepository {
    CastleOwner createCastleOwner(CastleOwner castleOwner);
    CastleOwner findById(UUID id);
}
