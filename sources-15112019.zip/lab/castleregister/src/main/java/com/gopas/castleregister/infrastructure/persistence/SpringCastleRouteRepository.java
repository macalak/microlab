package com.gopas.castleregister.infrastructure.persistence;

import com.gopas.castleregister.domain.model.CastleRoute;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.UUID;

public interface SpringCastleRouteRepository extends JpaRepository<CastleRoute, UUID> {
}
