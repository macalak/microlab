package com.gopas.castleregister.domain.event;

public class CastleCreatedEvent {
    public String castleId;
    public String name;
    public String description;
    public Double latitude;
    public Double longitude;
    public String ownerName;

    @Override
    public String toString() {
        return "CastleCreatedEvent{" +
                "castleId='" + castleId + '\'' +
                ", name='" + name + '\'' +
                ", description='" + description + '\'' +
                ", latitude=" + latitude +
                ", longitude=" + longitude +
                ", ownerName='" + ownerName + '\'' +
                '}';
    }
}
