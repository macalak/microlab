package com.gopas.castleregister.infrastructure.persistence;

import com.gopas.castleregister.domain.model.CastleOwner;
import com.gopas.castleregister.domain.model.CastleOwnerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.UUID;

@Repository
public class JpaCastleOwneRepository implements CastleOwnerRepository {

    @Autowired
    SpringDataCastleOwnerRepository springDataCastleOwnerRepository;

    @Override
    public CastleOwner createCastleOwner(CastleOwner castleOwner) {
        return springDataCastleOwnerRepository.save(castleOwner);
    }

    @Override
    public CastleOwner findById(UUID id) {
        return springDataCastleOwnerRepository.findById(id).orElseGet(null);
    }
}
