package com.gopas.castleregister.application.util;

import java.util.HashMap;
import java.util.Map;

public class ThreadContext {
	public static final String TOKEN = "token";
	public static final String TOKEN_HEADER_ATTRIBUTE_NAME = "authorization";
	public static final String TOKEN_HEADER_ATTRIBUTE_BEARER_PREFIX = "bearer ";	
	
	private static final ThreadLocal<Map<String, Object>> CURRENT = new ThreadLocal<Map<String, Object>>();

	/**
	 * General thread data Map
	 */
    public static Map<String, Object> getThreadData() {
    	Map<String, Object> threadData = CURRENT.get();
    	if ( threadData == null ) {
    		threadData = new HashMap<String, Object>();
    	} 	
    	return threadData; 
    }
	
    public static void setThreadData(Map<String, Object> threadData) {
    	CURRENT.set(threadData);
    }
    
    /* 
     * Token
     */
    public static String getToken() {
    	Map<String, Object> threadData = getThreadData();
    	String token = (String) threadData.get(TOKEN);
    	return (token == null) ? "" : token;
    }

    public static void setToken(String token) {
    	Map<String, Object> threadData = getThreadData();
    	threadData.put(TOKEN, token);
    	CURRENT.set(threadData);
    }
    
}
