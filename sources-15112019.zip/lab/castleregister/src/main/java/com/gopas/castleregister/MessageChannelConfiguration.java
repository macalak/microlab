package com.gopas.castleregister;

import com.gopas.castleregister.infrastructure.messaging.MessageChannelInterface;
import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.context.annotation.Configuration;

@Configuration
@EnableBinding(MessageChannelInterface.class)
public class MessageChannelConfiguration {
}
