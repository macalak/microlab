package com.gopas.castleregister.infrastructure.persistence;

import com.gopas.castleregister.domain.model.CastleOwner;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.UUID;

public interface SpringDataCastleOwnerRepository extends JpaRepository<CastleOwner, UUID> {
}
