package com.gopas.castleregister.infrastructure.messaging;

import org.springframework.cloud.stream.annotation.Output;
import org.springframework.messaging.MessageChannel;

public interface MessageChannelInterface {
    final String CASTLEREGISTER_SOURCE = "castleregister-source";

    @Output(CASTLEREGISTER_SOURCE)
    MessageChannel sendCastleRegisterEvent();
}
