package com.gopas.castleregister.application.api;

import com.gopas.castleregister.domain.event.CastleEventPublisher;
import com.gopas.castleregister.domain.model.*;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/castles")
public class CastleRestController {
    @Autowired
    private Logger LOGGER;

    private final CastleRepository castleRepository;
    private final CastleRouteRepository castleRouteRepository;
    private final CastleEventPublisher castleEventPublisher;

    public CastleRestController(CastleRepository castleRepository,
                                CastleRouteRepository castleRouteRepository,
                                CastleEventPublisher castleEventPublisher) {
        this.castleRepository = castleRepository;
        this.castleRouteRepository = castleRouteRepository;
        this.castleEventPublisher = castleEventPublisher;
    }

    @PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Void> createNewCastle(@RequestBody CastleDTO castleDTO){
        LOGGER.info("Going to cerate Castle: {}", castleDTO);
        Castle castleToCreate = map(castleDTO);
        castleToCreate.setCastleRouteRepository(castleRouteRepository);
        castleToCreate.setCastleRepository(castleRepository);
        castleToCreate.setCastleEventPublisher(castleEventPublisher);
        castleToCreate.create();
        return ResponseEntity.status(HttpStatus.CREATED).build();
    }

    @GetMapping(produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<CastleDTO>> getAllCastles(){
        LOGGER.info("Going to find all Castles");
        return ResponseEntity.status(HttpStatus.OK).body(castleRepository.findAll()
                .stream()
                .map(p -> map(p))
                .collect(Collectors.toList()));
    }

    private Castle map(CastleDTO castleDTO){
        Castle castle = null;
        if(castleDTO != null){
            castle = new Castle(UUID.fromString(castleDTO.id),
                    castleDTO.name,
                    castleDTO.description,
                    new CastleLocation(castleDTO.latitude, castleDTO.longitude),
                    new CastleOwner(UUID.fromString(castleDTO.ownerId)));
            LOGGER.debug("{} mapped to {}", castleDTO, castle);
        }

        return castle;
    }

    private CastleDTO map(Castle castle){
        CastleDTO castleDTO = new CastleDTO();
        if(castle != null){
            castleDTO.id = castle.getId().toString();
            castleDTO.description = castle.getDescription();
            castleDTO.latitude = castle.getCastleLocation().getLatitude();
            castleDTO.longitude = castle.getCastleLocation().getLatitude();
            castleDTO.ownerId = castle.getCurrentOwner().getId().toString();
            castleDTO.name = castle.getName();
            LOGGER.debug("{} mapped to {}",castle, castleDTO);
        }
        return castleDTO;
    }
}
