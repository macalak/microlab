package com.gopas.castleregister.application.api;

import com.gopas.castleregister.domain.model.CastleOwner;
import com.gopas.castleregister.domain.model.CastleOwnerRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/owners")
public class CastleOwnerRestController {
    @Autowired
    private Logger LOGGER;

    private final CastleOwnerRepository castleOwnerRepository;

    public CastleOwnerRestController(CastleOwnerRepository castleOwnerRepository) {
        this.castleOwnerRepository = castleOwnerRepository;
    }

    @PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Void> createOwner(@RequestBody CastleOwnerDTO  castleOwnerDTO){
        LOGGER.info("Going to create Castle owner: {}", castleOwnerDTO);
        CastleOwner castleOwnerToCreate = map(castleOwnerDTO);
        castleOwnerToCreate.setCastleOwnerRepository(castleOwnerRepository);
        castleOwnerToCreate.create();
        return ResponseEntity.status(HttpStatus.CREATED).build();
    }

    private CastleOwner map(CastleOwnerDTO castleOwnerDTO){
        CastleOwner castleOwner = null;
        if(castleOwnerDTO != null){
            castleOwner = new CastleOwner(UUID.fromString(castleOwnerDTO.id),
                    castleOwnerDTO.name);
        }
        return castleOwner;
    }
}
