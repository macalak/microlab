package com.gopas.castleregister.infrastructure.persistence;

import com.gopas.castleregister.domain.model.Castle;
import com.gopas.castleregister.domain.model.CastleRepository;
import com.gopas.castleregister.infrastructure.messaging.CastleEventPublisherImp;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public class JpaCastleRepository implements CastleRepository {
    private static final Logger LOGGER = LoggerFactory.getLogger(JpaCastleRepository.class);

    @Autowired
    SpringDataCastleRepository springDataCastleRepository;

    @Override
    public Castle createCastle(Castle castle) {
        LOGGER.info("Creating Castle in repository {}", castle);
        return springDataCastleRepository.save(castle);
    }

    @Override
    public void deleteCastle(UUID id) {
        springDataCastleRepository.deleteById(id);
    }

    @Override
    public List<Castle> findByName(String name) {
        return springDataCastleRepository.findByName(name);
    }

    @Override
    public Castle findById(UUID id) {
        return springDataCastleRepository.findById(id).orElseGet(null);
    }

    @Override
    public List<Castle> findByLocation(Double longitude, Double latitude, Double radius) {
        return springDataCastleRepository.findAll();
    }

    @Override
    public List<Castle> findAll() {
        LOGGER.info("Retrieving all xastles from repository");
        return springDataCastleRepository.findAll();
    }
}
