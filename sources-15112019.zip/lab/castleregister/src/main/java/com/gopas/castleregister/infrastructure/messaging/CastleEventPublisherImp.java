package com.gopas.castleregister.infrastructure.messaging;

import com.gopas.castleregister.domain.event.CastleCreatedEvent;
import com.gopas.castleregister.domain.event.CastleEventPublisher;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.stereotype.Component;

@Component
public class CastleEventPublisherImp implements CastleEventPublisher {
    private static final Logger LOGGER = LoggerFactory.getLogger(CastleEventPublisherImp.class);
    private final MessageChannelInterface messageChannel;

    public CastleEventPublisherImp(MessageChannelInterface messageChannel) {
        this.messageChannel = messageChannel;
    }

    @Override
    public void sendCastleCreatedEvent(CastleCreatedEvent event) {
        LOGGER.info("Sending event to event bus {}", event);
        messageChannel.sendCastleRegisterEvent().send(
                MessageBuilder.withPayload(event).build());
    }
}
