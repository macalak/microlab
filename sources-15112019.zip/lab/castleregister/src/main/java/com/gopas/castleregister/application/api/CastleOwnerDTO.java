package com.gopas.castleregister.application.api;

public class CastleOwnerDTO {
    public String id;
    public String name;
}
