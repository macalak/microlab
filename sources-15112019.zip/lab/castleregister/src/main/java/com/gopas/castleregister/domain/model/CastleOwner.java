package com.gopas.castleregister.domain.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Transient;
import java.util.UUID;

@Entity
public class CastleOwner {
    private @Id UUID id;
    private String name;

    @Transient
    private CastleOwnerRepository castleOwnerRepository;

    public CastleOwner(UUID id, String name) {
        this.id = id;
        this.name = name;
    }

    public CastleOwner(UUID id) {
        this.id = id;
    }

    public CastleOwner() {
    }

    // Business logic
    public void create(){
        castleOwnerRepository.createCastleOwner(this);
    }

    public void setCastleOwnerRepository(CastleOwnerRepository castleOwnerRepository) {
        this.castleOwnerRepository = castleOwnerRepository;
    }

    public void setName(String name) {
        this.name = name;
    }

    public UUID getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    @Override
    public String toString() {
        return "CastleOwner{" +
                "id=" + id +
                ", name='" + name + '\'' +
                '}';
    }
}
