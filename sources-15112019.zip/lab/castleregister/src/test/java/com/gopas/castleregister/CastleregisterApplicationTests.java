package com.gopas.castleregister;

import com.gopas.castleregister.domain.model.*;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.UUID;

class CastleregisterApplicationTests {

	@Test
	public void testAddRouteToCastle() {
		Castle castle = new Castle(UUID.randomUUID(),
				"My Castle",
				"Some desc",
				new CastleLocation(41.5445, 21.1154),
				new CastleOwner(UUID.randomUUID(), "My owner")
		);

		CastleRoute castleRoute = new CastleRoute(UUID.randomUUID(),
				"Nice route",
				"bla bla",
				100,
				new OpeningHours(),
				null );

		castle.setCastleRepository(Mockito.mock(CastleRepository.class));
		castle.setCastleRouteRepository(Mockito.mock(CastleRouteRepository.class));

		castle.addRoute(castleRoute);
		castle.addRoute(null);

		Assertions.assertNotNull(castle.getCastleRoutes());
		Assertions.assertEquals(1, castle.getCastleRoutes().size());
	}

	@Test
	public void testAddNullRouteToCastle() {
		Castle castle = new Castle(UUID.randomUUID(),
				"My Castle",
				"Some desc",
				new CastleLocation(41.5445, 21.1154),
				new CastleOwner(UUID.randomUUID(), "My owner")
		);

		castle.setCastleRepository(Mockito.mock(CastleRepository.class));
		castle.setCastleRouteRepository(Mockito.mock(CastleRouteRepository.class));

		castle.addRoute(null);

		Assertions.assertNotNull(castle.getCastleRoutes());
		Assertions.assertEquals(0, castle.getCastleRoutes().size());
	}

}
