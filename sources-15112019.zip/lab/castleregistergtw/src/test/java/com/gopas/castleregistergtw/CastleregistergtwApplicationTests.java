package com.gopas.castleregistergtw;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CastleregistergtwApplicationTests {

	@Test
	void contextLoads() {
	}

}
