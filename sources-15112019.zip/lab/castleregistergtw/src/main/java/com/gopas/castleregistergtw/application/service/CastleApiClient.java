package com.gopas.castleregistergtw.application.service;

import com.gopas.castleregistergtw.application.api.CastleDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;

@FeignClient("castleregister")
public interface CastleApiClient {
    @PostMapping(value="/castles", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Void> createNewCastle(@RequestBody CastleDTO castleDTO);

    @GetMapping(value="/castles", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<CastleDTO>> getAllCastles();

}
