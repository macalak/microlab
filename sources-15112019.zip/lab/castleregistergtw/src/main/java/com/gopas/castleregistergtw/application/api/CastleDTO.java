package com.gopas.castleregistergtw.application.api;

public class CastleDTO {
    public String id;
    public String name;
    public String description;
    public Double latitude;
    public Double longitude;
    public String ownerId;
}
