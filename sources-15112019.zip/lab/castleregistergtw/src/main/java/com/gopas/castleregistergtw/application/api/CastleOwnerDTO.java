package com.gopas.castleregistergtw.application.api;

public class CastleOwnerDTO {
    public String id;
    public String name;
}
