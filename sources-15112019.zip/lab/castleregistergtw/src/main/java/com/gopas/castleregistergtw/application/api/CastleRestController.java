package com.gopas.castleregistergtw.application.api;

import com.gopas.castleregistergtw.application.service.CastleApiClient;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/apigtw")
public class CastleRestController {
    private Logger LOGGER = LoggerFactory.getLogger(CastleRestController.class);

    @Autowired
    private CastleApiClient castleApiClient;

    @PostMapping(value = "/castles", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Void> createNewCastle(@RequestBody CastleDTO castleDTO){
        LOGGER.info("Going to cerate Castle: {}", castleDTO);
        // Message transformation
        return castleApiClient.createNewCastle(castleDTO);
    }

    @HystrixCommand(fallbackMethod = "getDefaultCastles")
    @GetMapping(value = "/castles", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<CastleModifiedDTO>> getAllCastles(){
      LOGGER.info("Getting all castles...");
      return ResponseEntity.status(HttpStatus.OK).body(castleApiClient.getAllCastles().getBody()
                .stream()
                .map(p -> map(p))
                .collect(Collectors.toList()));

    }

     private ResponseEntity<List<CastleModifiedDTO>> getDefaultCastles(){
        return ResponseEntity.status(HttpStatus.OK).build();
    }

    private CastleModifiedDTO map(CastleDTO castleDTO){
        CastleModifiedDTO modifiedDTO = new CastleModifiedDTO();
        modifiedDTO.id = castleDTO.id;
        modifiedDTO.latitude = castleDTO.latitude;
        modifiedDTO.longitude = castleDTO.longitude;
        modifiedDTO.name = modifiedDTO.name;
        return modifiedDTO;
    }
}
