package com.gopas.castleregistergtw.application.api;

public class CastleModifiedDTO {
    public String id;
    public String name;
    public Double latitude;
    public Double longitude;
}
