package com.gopas.castlegtw;

import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class CastleRouteConfiguration {
    @Bean
    public RouteLocator castleRegister(RouteLocatorBuilder routeLocatorBuilder){
        return routeLocatorBuilder.routes()
                .route("getallcastles", r -> r
                        .path("/**")
                        .uri("lb://castleregister"))
                .build();
    }
}
