package com.gopas.castlesearch.infrastructure.messaging;

import org.springframework.cloud.stream.annotation.Input;
import org.springframework.messaging.SubscribableChannel;

public interface MessageChannelInterface {
    final String CASTLEREGISTER_SINK = "castleregister-sink";

    @Input(CASTLEREGISTER_SINK)
    SubscribableChannel receiveCastleEvent();

}
