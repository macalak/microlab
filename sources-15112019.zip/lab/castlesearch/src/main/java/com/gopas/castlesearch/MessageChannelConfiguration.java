package com.gopas.castlesearch;

import com.gopas.castlesearch.infrastructure.messaging.MessageChannelInterface;
import org.springframework.cloud.stream.annotation.EnableBinding;

@EnableBinding(MessageChannelInterface.class)
public class MessageChannelConfiguration {
}
