package com.gopas.castlesearch.infrastructure.messaging;

import com.gopas.castlesearch.application.event.CastleCreatedEvent;
import com.gopas.castlesearch.domain.model.Castle;
import com.gopas.castlesearch.domain.model.CastleLocation;
import com.gopas.castlesearch.domain.model.CastleRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.UUID;

@Component
public class CastleEventConsumer {
    private static final Logger LOGGER = LoggerFactory.getLogger(CastleEventConsumer.class);

    private final CastleRepository castleRepository;

    public CastleEventConsumer(CastleRepository castleRepository) {
        this.castleRepository = castleRepository;
    }

    @StreamListener(MessageChannelInterface.CASTLEREGISTER_SINK)
    @Transactional
    public void consumeCastleCreatedEvent(CastleCreatedEvent castleCreatedEvent){
        LOGGER.info("Event received {}", castleCreatedEvent);
        Castle castleToCreate = map(castleCreatedEvent);
        castleToCreate.setCastleRepository(castleRepository);
        castleToCreate.create();
    }

    private Castle map (CastleCreatedEvent castleCreatedEvent){
        if(castleCreatedEvent != null){
            return new Castle(UUID.fromString(castleCreatedEvent.castleId),
                    castleCreatedEvent.name,
                    new CastleLocation(castleCreatedEvent.latitude, castleCreatedEvent.longitude),
                    castleCreatedEvent.ownerName);
        } else {
            return null;
        }
    }
}
