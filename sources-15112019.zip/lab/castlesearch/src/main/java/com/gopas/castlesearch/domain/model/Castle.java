package com.gopas.castlesearch.domain.model;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

@Entity
public class Castle {
    @Transient
    private final static Logger LOGGER = LoggerFactory.getLogger(Castle.class);

    @Id
    private UUID id;
    private String name;
    private CastleLocation castleLocation;
    private String ownerName;
    @OneToMany(mappedBy = "castle")
    private Set<CastleTour> castleTours = new HashSet<>();

    @Transient
    CastleRepository castleRepository;

    public Castle() {
    }

    public Castle(UUID id, String name, CastleLocation castleLocation, String ownerName) {
        this.id = id;
        this.name = name;
        this.castleLocation = castleLocation;
        this.ownerName = ownerName;
    }

    // Business logic
    public void create() {
        castleRepository.createCastle(this);
        LOGGER.info("Castle created: {}", this);
    }

    public void setCastleRepository(CastleRepository castleRepository) {
        this.castleRepository = castleRepository;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setCastleLocation(CastleLocation castleLocation) {
        this.castleLocation = castleLocation;
    }

    public void setOwnerName(String ownerName) {
        this.ownerName = ownerName;
    }

    public UUID getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public CastleLocation getCastleLocation() {
        return castleLocation;
    }

    public String getOwnerName() {
        return ownerName;
    }

    public Set<CastleTour> getCastleTours() {
        return castleTours;
    }

    @Override
    public String toString() {
        return "Castle{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", castleLocation=" + castleLocation +
                ", ownerName='" + ownerName + '\'' +
                ", castleTours=" + castleTours +
                ", castleRepository=" + castleRepository +
                '}';
    }
}



