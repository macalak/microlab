package com.gopas.castlesearch.domain.model;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.persistence.*;
import java.time.Instant;
import java.util.UUID;

@Entity
public class CastleTour {
    @Transient
    private final static Logger LOGGER = LoggerFactory.getLogger(CastleTour.class);

    @Id
    private UUID id;
    private String name;
    private String travelAgencyName;
    private Instant date;
    private Integer capacity;
    private Integer vacantPlaces;
    @ManyToOne
    @JoinColumn(name = "CASTLE_ID")
    private Castle castle;

    public CastleTour() {
    }

    public CastleTour(UUID id, String name, String travelAgencyName, Instant date, Integer capacity, Integer vacantPlaces, Castle castle) {
        this.id = id;
        this.name = name;
        this.travelAgencyName = travelAgencyName;
        this.date = date;
        this.capacity = capacity;
        this.vacantPlaces = vacantPlaces;
        this.castle = castle;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setTravelAgencyName(String travelAgencyName) {
        this.travelAgencyName = travelAgencyName;
    }

    public void setDate(Instant date) {
        this.date = date;
    }

    public void setCapacity(Integer capacity) {
        this.capacity = capacity;
    }

    public void setVacantPlaces(Integer vacantPlaces) {
        this.vacantPlaces = vacantPlaces;
    }

    public void setCastle(Castle castle) {
        this.castle = castle;
    }

    public UUID getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getTravelAgencyName() {
        return travelAgencyName;
    }

    public Instant getDate() {
        return date;
    }

    public Integer getCapacity() {
        return capacity;
    }

    public Integer getVacantPlaces() {
        return vacantPlaces;
    }

    public Castle getCastle() {
        return castle;
    }

    @Override
    public String toString() {
        return "CastleTour{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", travelAgencyName='" + travelAgencyName + '\'' +
                ", date=" + date +
                ", capacity=" + capacity +
                ", vacantPlaces=" + vacantPlaces +
                ", castle=" + castle +
                '}';
    }
}
