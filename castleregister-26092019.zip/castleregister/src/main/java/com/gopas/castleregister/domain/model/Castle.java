package com.gopas.castleregister.domain.model;

import com.gopas.castleregister.domain.event.CastleCreatedEvent;
import com.gopas.castleregister.domain.event.DomainEventPublisher;
import com.gopas.castleregister.domain.event.GenericEvent;
import org.springframework.context.ApplicationEventPublisher;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Entity
public class Castle {
    private @Id UUID id;
    private String name;
    @ManyToOne
    private Owner currentOwner;
    private CastleLocation location;
    private String description;
    private String address;
    private String webPage;
    private String foto;
    private Integer capacity;
    @OneToMany(mappedBy = "castle")
    private List<CastleRoute> routes = new ArrayList<>();

    @Transient
    private CastleRepository castleRepository;
    @Transient
    private CastleRouteRepository castleRouteRepository;
    @Transient
    private DomainEventPublisher domainEventPublisher;


    public Castle() {
    }

    public Castle(UUID id, String name) {
        this.id = id;
        this.name = name;
    }

    public Castle(UUID id, String name, CastleLocation location, String description, String address, String webPage, String foto, Integer capacity) {
        this.id = id;
        this.name = name;
        this.location = location;
        this.description = description;
        this.address = address;
        this.webPage = webPage;
        this.foto = foto;
        this.capacity = capacity;
    }

    public void setCastleRepository(CastleRepository castleRepository) {
        this.castleRepository = castleRepository;
    }

    public void setCastleRouteRepository(CastleRouteRepository castleRouteRepository) {
        this.castleRouteRepository = castleRouteRepository;
    }

    public void setDomainEventPublisher(DomainEventPublisher domainEventPublisher) {
        this.domainEventPublisher = domainEventPublisher;
    }

    public UUID getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Owner getCurrentOwner() {
        return currentOwner;
    }

    public void setCurrentOwner(Owner currentOwner) {
        this.currentOwner = currentOwner;
    }

    public CastleLocation getLocation() {
        return location;
    }

    public void setLocation(CastleLocation location) {
        this.location = location;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getWebPage() {
        return webPage;
    }

    public void setWebPage(String webPage) {
        this.webPage = webPage;
    }

    public String getFoto() {
        return foto;
    }

    public void setFoto(String foto) {
        this.foto = foto;
    }

    public Integer getCapacity() {
        return capacity;
    }

    public void setCapacity(Integer capacity) {
        this.capacity = capacity;
    }

    public List<CastleRoute> getRoutes() {
        return routes;
    }

    public void setRoutes(List<CastleRoute> routes) {
        this.routes = routes;
    }

    public void addRoute(CastleRoute castleRoute){
        if(castleRoute != null) {
            routes.add(castleRoute);
            castleRoute.setCastle(this);
            castleRouteRepository.createCastleRoute(castleRoute);
        }
    }

    public void create(){
        castleRepository.createCastle(this);
        CastleCreatedEvent castleCreatedEvent = new CastleCreatedEvent(id.toString(),
                name,
                null,
                location.getLongitude(),
                location.getLatitude(),
                description,
                address,
                webPage,
                foto,
                capacity);
        GenericEvent<CastleCreatedEvent> event = new GenericEvent<>(castleCreatedEvent);
        domainEventPublisher.fireEvent(event);
    }
}
