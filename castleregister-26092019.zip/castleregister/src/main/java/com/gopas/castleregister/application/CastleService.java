package com.gopas.castleregister.application;

import com.gopas.castleregister.domain.model.Castle;
import com.gopas.castleregister.domain.model.CastleRepository;
import com.gopas.castleregister.domain.model.CastleRoute;
import com.gopas.castleregister.domain.model.CastleRouteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
public class CastleService {
    @Autowired
    CastleRepository castleRepository;

    @Autowired
    CastleRouteRepository castleRouteRepository;

    @Transactional
    public void addRouteToCastle(CastleRoute castleRoute, Castle castle){
        castle.setCastleRepository(castleRepository);
        castle.setCastleRouteRepository(castleRouteRepository);
        castle.addRoute(castleRoute);
    }
}
