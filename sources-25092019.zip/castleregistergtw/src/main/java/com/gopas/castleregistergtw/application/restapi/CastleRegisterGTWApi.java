package com.gopas.castleregistergtw.application.restapi;

import com.gopas.castleregister.application.restapi.OwnerDTO;
import com.gopas.castleregistergtw.service.CastleRegisterFeignClient;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.netflix.ribbon.proxy.annotation.Hystrix;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

@RestController
@RequestMapping("/api-castleregister")
public class CastleRegisterGTWApi {

    @Autowired
    CastleRegisterFeignClient feignClient;

    @RequestMapping(consumes={"application/json"}, value="/owner", method= RequestMethod.POST )
    public ResponseEntity<Void> createOwner(@RequestBody @NotNull @Valid OwnerDTO ownerDTO){
        return feignClient.createOwner(ownerDTO);
    }

    @HystrixCommand(fallbackMethod = "getOwnerFallback")
    @RequestMapping(produces={"application/json"}, value="/owner/{id}", method= RequestMethod.GET )
    public OwnerDTO getOwner(@PathVariable("id") String id){
        return feignClient.getOwner(id);
    }

    private OwnerDTO getOwnerFallback(String id){
        OwnerDTO defaultOwner = new OwnerDTO();
        defaultOwner.id="default";
        defaultOwner.name="default owner";
        return defaultOwner;
    }
}
