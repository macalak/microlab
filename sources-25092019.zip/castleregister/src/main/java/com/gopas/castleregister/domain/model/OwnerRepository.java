package com.gopas.castleregister.domain.model;

import java.util.List;
import java.util.UUID;

public interface OwnerRepository {
    Owner createOwner(Owner owner);
    void deleteOwner(UUID ownerId);
    List<Owner> findByName(String name);
    Owner findById(UUID id);
}
