package com.gopas.castleregister.application.restapi;

import com.gopas.castleregister.application.event.ExternalCastleCreatedEvent;
import com.gopas.castleregister.domain.model.*;
import com.gopas.castleregister.infrastructure.messaging.CastleEventGateway;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.util.UUID;

@RestController
@RequestMapping("/")
public class CastleRegisterApi {

    @Autowired
    OwnerRepository ownerRepository;

    @Autowired
    CastleRepository castleRepository;

    @Autowired
    private CastleEventGateway castleEventGateway;

    @Autowired
    ModelMapper modelMapper;

    @RequestMapping(consumes={"application/json"}, value="/owner", method= RequestMethod.POST )
    public ResponseEntity<Void> createOwner(@RequestBody @NotNull @Valid OwnerDTO ownerDTO){
        Owner owner = new Owner(UUID.fromString(ownerDTO.id), ownerDTO.name);
        ownerRepository.createOwner(owner);
        return ResponseEntity.status(HttpStatus.CREATED).build();
    }

    @RequestMapping(produces={"application/json"}, value="/owner/{id}", method= RequestMethod.GET )
    public OwnerDTO getOwner(@PathVariable("id") String id){
        return modelMapper.map(ownerRepository.findById(UUID.fromString(id)), OwnerDTO.class);
    }


    @RequestMapping(consumes={"application/json"}, value="/castle", method= RequestMethod.POST )
    public ResponseEntity<Void> createCastle(@RequestBody @NotNull @Valid CastleDTO castleDTO){
        Castle castle = new Castle(UUID.fromString(castleDTO.id),
                castleDTO.name,
                new CastleLocation(castleDTO.latitude, castleDTO.longitude),
                castleDTO.description,
                castleDTO.address,
                castleDTO.webPage,
                castleDTO.foto,
                castleDTO.capacity);
        castleRepository.createCastle(castle);
        castleEventGateway.sendCastleCreatedEvent(modelMapper.map(castleDTO, ExternalCastleCreatedEvent.class));
        return ResponseEntity.status(HttpStatus.CREATED).build();
    }
}
