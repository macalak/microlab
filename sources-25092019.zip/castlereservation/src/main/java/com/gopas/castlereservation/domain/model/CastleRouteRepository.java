package com.gopas.castlereservation.domain.model;

public interface CastleRouteRepository {
    CastleRoute createCastleRoute(CastleRoute castleRoute);
}
