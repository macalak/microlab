package sk.ite.got.castle.domain.event;

/**
 * Created by macalaki on 31.01.2017.
 */
public class CastleCreatedEvent {
    private String id;
    private String name;
    private String ruler;
    private String location;

    public CastleCreatedEvent(String id, String name, String ruler, String location) {
        this.id = id;
        this.name = name;
        this.ruler = ruler;
        this.location = location;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getRuler() {
        return ruler;
    }

    public String getLocation() {
        return location;
    }
}
