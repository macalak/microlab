insert into CASTLE (ID, NAME, RULER, LOCATION, VERSION) values ('602331668f57445e95e38a3259d72332','Harrenhal','House Baelish','The Riverlands',1);
insert into CASTLE (ID, NAME, RULER, LOCATION, VERSION) values ('4012a733d16f44bd9fccd2244d3de1a7','Dragonstone','House Baratheon of Dragonstone','Dragonstone',1);
insert into CASTLE (ID, NAME, RULER, LOCATION, VERSION) values ('d5abd992cfc449e88edce864fa8e7257','Casterly Rock','House Lannister','The Westerlands',1);
insert into CASTLE (ID, NAME, RULER, LOCATION, VERSION) values ('f9b01782bea64579bb0e88b6c4b22770','Winterfell','House Bolton','The North',1);
insert into CASTLE (ID, NAME, RULER, LOCATION, VERSION) values ('be8ea239549e4ed5a2e868b13938a39e','Riverrun','House Tully','The Westeros',1);
insert into CASTLE (ID, NAME, RULER, LOCATION, VERSION) values ('085d25fbfe334f7d8f4e941d6262fa71','The Eyrie','House Arryn','The Westeros',1);
insert into CASTLE (ID, NAME, RULER, LOCATION, VERSION) values ('9267f98ee6124425953ea3bf0aa3fae4','Castle Black','The Nights Watch','The Westeros',1);
insert into CASTLE (ID, NAME, RULER, LOCATION, VERSION) values ('2a8b5df591884162818d1e7eb468e74f','Moat Cailin','House Bolton','The Westeros',1);
insert into CASTLE (ID, NAME, RULER, LOCATION, VERSION) values ('0f80f684359541c5adb4ffef44540e6b','The Dreadfort','House Bolton','The Westeros',1);
insert into CASTLE (ID, NAME, RULER, LOCATION, VERSION) values ('145ce29a3c3c4f5f9f3842eef7f090d0','Red Keep','The King of the Andals and the First Men','Kings Landing',1);
insert into CASTLE (ID, NAME, RULER, LOCATION, VERSION) values ('a057f77bce4340b3905bc5c7fa28f66c','Storm''s End','House Bolton','The Westeros',1);
insert into CASTLE (ID, NAME, RULER, LOCATION, VERSION) values ('26409d761589432e9ba8f30dc921b8b4','Highgarden','House Tyrell','The Westeros',1);
insert into CASTLE (ID, NAME, RULER, LOCATION, VERSION) values ('218d7c1b1c104566bcca2eaa178005da','The Twins','House Frey','The Westeros',1);
insert into CASTLE (ID, NAME, RULER, LOCATION, VERSION) values ('d7e0e3b9eb6d4587b237d43c7b6f17e6','Last Hearth','House Umber','The Westeros',1);
insert into CASTLE (ID, NAME, RULER, LOCATION, VERSION) values ('2d44b6843f5d4ed8ad7fecd1981839c8','The Citadel','The Conclave, Order of Maesters','The Reach',1);
insert into CASTLE (ID, NAME, RULER, LOCATION, VERSION) values ('2cac087457614090962ec451dcc1e908','The Nightfort','The Westeros','The Night''s Watch',1);
-- alter sequence HIBERNATE_SEQUENCE restart with 18
