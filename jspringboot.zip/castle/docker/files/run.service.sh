#!/bin/bash

cd /opt/itexperts/service/

java -jar service.jar
