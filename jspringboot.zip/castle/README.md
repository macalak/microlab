# CASTLE Module
It represents the Castle register, which maintains castles data. It provides castle data management services, such as
a castle record creation and update, or search for castles based on input criteria. 

## How to run 
This module connects to the RabbitMQ broker. You can run it directly from the Java IDE with required parameters, or
you can build jar package and run it as `java -jar castle-<version>.jar <program parameters>` You can package the application
as the Docker image and run it inside container. 
 
* Program parameters: `--RABBITMQ_IP=192.168.99.100` 