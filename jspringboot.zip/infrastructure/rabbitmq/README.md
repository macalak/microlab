# Spinup RabbitMQ locally
`docker-compose up -d`