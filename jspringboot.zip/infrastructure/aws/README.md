* RancherOS on AWS: https://docs.rancher.com/os/running-rancheros/cloud/aws/
* Connect to my instance: ssh -i "aws_itexperts.pem" rancher@ec2-52-59-207-80.eu-central-1.compute.amazonaws.com

