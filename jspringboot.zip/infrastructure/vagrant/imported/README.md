Use this directory as Vagrant working directory, after you imported microservices.box.
Just run `vagrant up`.