package ite.librarymaster.application.service;

import ite.librarymaster.application.dto.BookDTO;
import ite.librarymaster.application.event.BookCreatedEvent;
import ite.librarymaster.application.event.BookDeletedEvent;
import ite.librarymaster.application.exception.ItemNotFoundException;
import ite.librarymaster.domain.model.Book;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;


import ite.librarymaster.domain.model.BookRepository;
import ite.librarymaster.infrastructure.messaging.LibraryEventPublisher;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class LibraryServiceImpl implements LibraryService{
    final private static Logger LOG = LoggerFactory.getLogger(LibraryServiceImpl.class);

	@Autowired
	private BookRepository bookRepository;
    @Autowired
    private ModelMapper modelMapepr;
    @Autowired
    private LibraryEventPublisher eventPublisher;


    @Override
	public List<BookDTO> getAllBooks() {
        LOG.info("Retrieving all books ...");
        return bookRepository.findAll().stream()
                .map(book -> modelMapepr.map(book, BookDTO.class))
                .collect(Collectors.toList());
	}

    @Override
    public BookDTO getBookById(Long id) throws ItemNotFoundException {
        LOG.info("Retrieving book identified by id:{} ...", id);
        Optional<Book> book = bookRepository.findById(id);
        if(book.isPresent()){
            return modelMapepr.map(book.get(), BookDTO.class);
        }else {
            throw new ItemNotFoundException("Book with id=" + id + " not found.");
        }
    }

    @Override
    public Long createBook(BookDTO bookDTO) {
        LOG.info("Creating book with details:{} ...", bookDTO);
        Book createdBook=bookRepository.save(modelMapepr.map(bookDTO, Book.class));
        LOG.info("Publishing event:{} ...");
        bookDTO.id=createdBook.getId();
        eventPublisher.send(modelMapepr.map(bookDTO, BookCreatedEvent.class));
        return createdBook.getId();
    }

    @Override
    public void deleteBook(Long id) throws ItemNotFoundException {
        LOG.info("Deleting book with id{}", id);
        Optional<Book> book = bookRepository.findById(id);
        if(book.isPresent()){
            bookRepository.delete(book.get());
            LOG.info("Book deleted.");
            LOG.info("Publishing event:{} ...");
            BookDeletedEvent bookDeletedEvent = new BookDeletedEvent();
            bookDeletedEvent.id=id;
            eventPublisher.send(bookDeletedEvent);

        }else {
            throw new ItemNotFoundException("Book to delete with id=" + id + " not found.");
        }
    }
}
