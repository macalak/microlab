# Library Search Module with Spring Integration

----
* https://docs.spring.io/spring-integration/docs/5.0.3.RELEASE/reference/html/amqp.html#amqp-inbound-channel-adapter