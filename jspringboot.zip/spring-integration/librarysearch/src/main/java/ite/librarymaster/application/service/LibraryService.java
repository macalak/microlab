package ite.librarymaster.application.service;

import ite.librarymaster.application.dto.BookDTO;
import ite.librarymaster.application.exception.ItemNotFoundException;

import java.util.List;
import java.util.Map;

public interface LibraryService {
	
	List<BookDTO> getBooks(Map<String,String> filter);
	Long createBook(BookDTO bookDTO);
	void deleteBook(Long id) throws ItemNotFoundException;

}
