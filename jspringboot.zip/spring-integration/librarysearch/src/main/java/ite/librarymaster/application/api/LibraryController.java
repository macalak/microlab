package ite.librarymaster.application.api;

import ite.librarymaster.application.dto.BookDTO;
import ite.librarymaster.application.exception.ItemNotFoundException;
import ite.librarymaster.application.service.LibraryService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.constraints.NotNull;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Library REST Controller.
 * 
 * @author macalak@itexperts.sk
 *
 */
@RestController
@RequestMapping("/library")
public class LibraryController {
	final private static Logger LOG = LoggerFactory.getLogger(LibraryController.class);
    
    @Autowired
    LibraryService libraryService;
    
    @RequestMapping(produces={"application/json"}, value="/books", method=RequestMethod.GET )
    public List<BookDTO> searchBook(@RequestParam(value = "isbn", required = false) String isbn,
                              @RequestParam(value = "author", required = false) String author,
                              @RequestParam(value = "title", required = false) String title) throws ItemNotFoundException{
    	LOG.info("Searching for books isbn:{}, author:{}, title:{} ...",isbn,author,title);
        return libraryService.getBooks(getFilter(isbn,author,title));
    }

    private Map<String,String> getFilter(String isbn, String author, String title){
        HashMap<String,String> filter = new HashMap<>();
        if(isbn!=null && !isbn.isEmpty()) filter.put("ISBN",isbn);
        if(author!=null && !author.isEmpty()) filter.put("AUTHOR",author);
        if(title!=null && !title.isEmpty()) filter.put("TITLE", title);
        return filter;
    }





}
