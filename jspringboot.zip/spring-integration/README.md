# Example of modularized application with Spring Integration
![modularized](docs/images/LM-library-modularized-int-overview.jpg)

## The Main concept
* Inbound Channel Adapters - are used for one-way integration bringing data into the messaging application. 
* Outbound Channel Adapters - are used for one-way integration to send data out of the messaging application. 
* Inbound Gateways - are used for a bidirectional integration flow where some other system invokes the messaging application and receives a reply.
* Outbound Gateways are used for a bidirectional integration flow where the messaging application invokes some external service or entity, expecting a result.
