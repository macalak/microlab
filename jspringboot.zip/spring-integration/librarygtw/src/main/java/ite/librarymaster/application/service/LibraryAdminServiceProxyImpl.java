package ite.librarymaster.application.service;

import ite.librarymaster.application.dto.BookDTO;
import ite.librarymaster.application.exception.ItemNotFoundException;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.Arrays;
import java.util.List;

@Service
public class LibraryAdminServiceProxyImpl implements LibraryAdminServiceProxy {
    final private static Logger LOG = LoggerFactory.getLogger(LibraryAdminServiceProxyImpl.class);

	@Autowired
	private RestTemplate restTemplate;
    @Autowired
    private ModelMapper modelMapepr;

    @Value("${library.gtw.admin.uri}")
    private String adminApiUri;

    @Override
	public List<BookDTO> getAllBooks() {
        LOG.info("Retrieving all books using Admin API ...");
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        // Uncomment to pass JWT token
        // headers.add("Authorization","Bearer "+activeSession.getApiAccessToken());
        HttpEntity httpRequest = new HttpEntity(headers);
        ResponseEntity<List<BookDTO>> response = restTemplate.exchange(adminApiUri + "/library/books",
                HttpMethod.GET, httpRequest, new ParameterizedTypeReference<List<BookDTO>>() {});
        // TODO: Handle HTTP 500 errors
        return response.getBody();
	}

    @Override
    public BookDTO getBookById(Long id) throws ItemNotFoundException {
        LOG.info("Retrieving book identified by id:{} ...", id);
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        // Uncomment to pass JWT token
        // headers.add("Authorization","Bearer "+activeSession.getApiAccessToken());
        HttpEntity httpRequest = new HttpEntity(headers);
        ResponseEntity<BookDTO> response = restTemplate.exchange(adminApiUri + "/library/books/" +id,
                HttpMethod.GET, httpRequest, BookDTO.class);
        // TODO: Handle HTTP 404,500 errors
        return response.getBody();
    }

    @Override
    public String createBook(BookDTO bookDTO) {
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        // Uncomment to pass JWT token
        // headers.add("Authorization","Bearer "+activeSession.getApiAccessToken());
        HttpEntity httpRequest = new HttpEntity(bookDTO, headers);
        ResponseEntity<Void> response = restTemplate.exchange(adminApiUri + "/library/books",
                HttpMethod.POST, httpRequest, Void.class);
        // TODO: Handle HTTP 500 errors
        return response.getHeaders().get(HttpHeaders.LOCATION).get(0);
    }

    @Override
    public void deleteBook(Long id) throws ItemNotFoundException {
        LOG.info("Deleting book with id{}", id);
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        // Uncomment to pass JWT token
        // headers.add("Authorization","Bearer "+activeSession.getApiAccessToken());
        HttpEntity httpRequest = new HttpEntity(headers);
        ResponseEntity<Void> response = restTemplate.exchange(adminApiUri + "/library/books/" + id,
                HttpMethod.DELETE, httpRequest, Void.class);
        // TODO: Handle HTTP 404,500 errors
    }
}
