package ite.librarymaster.application.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.integration.annotation.Poller;
import org.springframework.integration.annotation.ServiceActivator;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

@Component
public class PrintService {
    private static final Logger LOG= LoggerFactory.getLogger(PrintService.class);

    //@ServiceActivator(inputChannel = "searchReplyChannel")
    public void printRequest( Message<?> message){
        message.getHeaders().entrySet().stream().forEach(e-> LOG.info(e.toString()));
        LOG.info(message.getPayload().toString());
    }

    //@ServiceActivator(inputChannel = "searchBookResponses")
    public void printResponse( Message<?> message){
        message.getHeaders().entrySet().stream().forEach(e-> LOG.info(e.toString()));
        LOG.info(message.getPayload().toString());
    }
}
