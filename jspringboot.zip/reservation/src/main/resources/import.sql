insert into CASTLE (ID, NAME) values ('602331668f57445e95e38a3259d72332','Harrenhal');
insert into CASTLE (ID, NAME) values ('4012a733d16f44bd9fccd2244d3de1a7','Dragonstone');
insert into CASTLE (ID, NAME) values ('d5abd992cfc449e88edce864fa8e7257','Casterly Rock');
insert into CASTLE (ID, NAME) values ('f9b01782bea64579bb0e88b6c4b22770','Winterfell');
insert into CASTLE (ID, NAME) values ('be8ea239549e4ed5a2e868b13938a39e','Riverrun');
insert into CASTLE (ID, NAME) values ('085d25fbfe334f7d8f4e941d6262fa71','The Eyrie');
insert into CASTLE (ID, NAME) values ('9267f98ee6124425953ea3bf0aa3fae4','Castle Black');
insert into CASTLE (ID, NAME) values ('2a8b5df591884162818d1e7eb468e74f','Moat Cailin');
insert into CASTLE (ID, NAME) values ('0f80f684359541c5adb4ffef44540e6b','The Dreadfort');
insert into CASTLE (ID, NAME) values ('145ce29a3c3c4f5f9f3842eef7f090d0','Red Keep');
insert into CASTLE (ID, NAME) values ('a057f77bce4340b3905bc5c7fa28f66c','Storm''s End');
insert into CASTLE (ID, NAME) values ('26409d761589432e9ba8f30dc921b8b4','Highgarden');
insert into CASTLE (ID, NAME) values ('218d7c1b1c104566bcca2eaa178005da','The Twins');
insert into CASTLE (ID, NAME) values ('d7e0e3b9eb6d4587b237d43c7b6f17e6','Last Hearth');
insert into CASTLE (ID, NAME) values ('2d44b6843f5d4ed8ad7fecd1981839c8','The Citadel');
insert into CASTLE (ID, NAME) values ('2cac087457614090962ec451dcc1e908','The Nightfort');

-- Registered Customers
insert into CUSTOMER (ID, EMAIL, NAME, SURNAME, VERSION) values ('1376ef942b2641439f0bdeaa8cc388dc', 'john.snow@got.net' , 'John', 'Snow', 1)
insert into CUSTOMER (ID, EMAIL, NAME, SURNAME, VERSION) values ('44b299c0249147c4bce59dc4d6d0acd9', 'arya.stark@got.net' , 'Arya', 'Stark', 1)

-- Example PERIOD
insert into RES_PERIOD (ID, CASTLE_ID, CANCELED_AT, CREATED_AT, DATE_FROM, DATE_TO, FINISHED, MAX_NUMBER_OF_VISITORS, NUMBER_OF_VISITORS, PRICE_FOR_VISITOR, PROGRAM, VERSION ) values('79ca50befd354086a36c36a86514f6c3', '602331668f57445e95e38a3259d72332', NULL, '2019-01-01', '2019-01-01', '2019-01-02', FALSE, 25, 0, 5.50, 'Basic',1);

-- Example Reservation for PERIOD ID=1
insert into RESERVATION (ID, CANCEL_AT, CREATE_AT, CUSTOMER_ID, LAST_MODIFIED, NOTE, NUMBER_OF_GUESTS, PERIOD_ID, TOTAL_PRICE, VERSION ) values ('daad03c7c0914cf18d2831c422559f41', NULL, '2018-12-10', '1376ef942b2641439f0bdeaa8cc388dc', '2018-12-10', 'First visit', 3, '79ca50befd354086a36c36a86514f6c3', 16.50, 1);

-- Guests for RESERVATION ID=1
insert into GUEST (BOOKING_ID, DISCOUNT_CARD_ID, NAME, SURNAME) values ('44b299c0249147c4bce59dc4d6d0acd9', NULL, 'John', 'Snow');
insert into GUEST (BOOKING_ID, DISCOUNT_CARD_ID, NAME, SURNAME) values ('44b299c0249147c4bce59dc4d6d0acd9', NULL, 'Eddard', 'Stark');
insert into GUEST (BOOKING_ID, DISCOUNT_CARD_ID, NAME, SURNAME) values ('44b299c0249147c4bce59dc4d6d0acd9', NULL, 'Robb', 'Stark');

-- alter sequence HIBERNATE_SEQUENCE restart with 18



