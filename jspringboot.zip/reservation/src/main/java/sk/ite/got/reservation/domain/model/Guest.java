package sk.ite.got.reservation.domain.model;

import javax.persistence.*;
import java.util.Date;
import java.util.UUID;

@Embeddable
public class Guest {
	private String name = null;
	private String surname = null;
	private UUID  discountCardId;

	public Guest(String name, String surname, UUID discountCardId) {
		this.name = name;
		this.surname = surname;
		this.discountCardId = discountCardId;
	}

	// Required by modelmapper
	public Guest() {
	}

	public String getName() {
		return name;
	}

	public String getSurname() {
		return surname;
	}

	public UUID getDiscountCardId() {
		return discountCardId;
	}
}
