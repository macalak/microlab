package sk.ite.got.reservation.application.service;

import sk.ite.got.reservation.application.dto.DTOReservation;

import java.util.Date;
import java.util.List;
import java.util.UUID;

public interface ReservationService {
	UUID createReservationPeriod(UUID castleId, Date from, Date to, float priceForVisitor, int maxNumberOfVisitors);
	UUID createReservation(UUID customerId, UUID periodId, String note);
	void addGuestToReservation(UUID bookingId, String name, String surname, UUID discountCardId);
	void cancelReservation(UUID bookingId);
    List<DTOReservation> getAllReservationsForCustomer(String customerId);

}
