package sk.ite.got.reservation.application.dto;

public class DTOGuest {
	public String name = null;
	public String surname = null;
	public Long  discountCardId;

}
