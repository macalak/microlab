package sk.ite.got.reservation.domain.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Version;
import java.util.Date;
import java.util.UUID;

@Entity
public class ResPeriod {
	private @Id UUID id;
	private @Version Long version;
	private UUID castleId;
	private Date dateFrom;
	private Date dateTo;
	private float priceForVisitor;
	private int numberOfVisitors;
	private int maxNumberOfVisitors;
	private Date canceledAt;
	private Date createdAt;
	private boolean finished;
	private String program;

	public ResPeriod() {
	}

	public ResPeriod(UUID castleId, Date from, Date to, float priceForVisitor, int maxNumberOfVisitors) {
		this.castleId = castleId;
		this.dateFrom = from;
		this.dateTo = to;
		this.priceForVisitor = priceForVisitor;
		this.maxNumberOfVisitors = maxNumberOfVisitors;
	}

	public UUID getId() {
		return id;
	}
}
