package sk.ite.got.reservation.application.dto;


public class DTOCastle {
	public Long id;
	public String name;
}
