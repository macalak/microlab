package sk.ite.got.reservation.application.service;

import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;


import org.modelmapper.ModelMapper;
import org.slf4j.Logger;

import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import sk.ite.got.reservation.application.dto.DTOReservation;
import sk.ite.got.reservation.domain.model.ResPeriod;
import sk.ite.got.reservation.infrastructure.persistence.ReservationRepository;
import sk.ite.got.reservation.infrastructure.persistence.ResPeriodRepository;
import sk.ite.got.reservation.domain.model.Reservation;
import sk.ite.got.reservation.domain.model.Guest;

@Service
public class ReservationServiceImpl implements ReservationService {
	final Logger LOG = LoggerFactory.getLogger(ReservationServiceImpl.class);

	@Autowired
	private ReservationRepository reservationRepository;
	@Autowired
	private ResPeriodRepository resPeriodRepository;
	@Autowired
	ModelMapper dtoMapper;

	@Override
	public UUID createReservationPeriod(UUID castleId, Date from, Date to, float priceForVisitor, int maxNumberOfVisitors) {
		ResPeriod resPeriod = new ResPeriod(castleId,from,to,priceForVisitor,maxNumberOfVisitors);
		resPeriodRepository.save(resPeriod);
		return resPeriod.getId();
	}

	@Override
	public UUID createReservation(UUID customerId, UUID periodId, String note) {
		Reservation newBooking = new Reservation(customerId,periodId,note);
		reservationRepository.save(newBooking);
		return newBooking.getId();
	}

	@Override
	public void addGuestToReservation(UUID bookingId, String name, String surname, UUID discountCardId) {
		Reservation booking= reservationRepository.getOne(bookingId);
		booking.addGuest(new Guest(name,surname,discountCardId));
		reservationRepository.save(booking);
	}

	@Override
	public void cancelReservation(UUID bookingId) {
		Reservation booking= reservationRepository.getOne(bookingId);
		booking.cancel();
	}

	@Override
	public List<DTOReservation> getAllReservationsForCustomer(String customerId) {
		Collection<Reservation> byCustomerId = reservationRepository.getByCustomerId(UUID.fromString(customerId));
		return StreamSupport.stream(byCustomerId.spliterator(), false)
				.map(p -> dtoMapper.map(p, DTOReservation.class))
				.collect(Collectors.toList());
	}
}
