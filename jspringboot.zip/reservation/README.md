﻿# reservationservice



## Run 

* `--RABBITMQ_IP=192.168.99.100`