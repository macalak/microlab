package sk.ite.got.gateway.reservation.application.dto;

public class DTOCustomer {
	public  Long id;
	public String name;
	public String surname;
	public String email;
}