package sk.ite.got.gateway.reservation.application.dto;

public class DTOGuest {
	public String name = null;
	public String surname = null;
	public Long  discountCardId;

}
