package sk.ite.got.gateway.reservation.application.restapi;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import sk.ite.got.gateway.reservation.application.dto.DTOReservation;
import sk.ite.got.gateway.reservation.application.service.ReservationReader;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Api(tags = "Reservations endpoint")
@RestController
@RequestMapping("/reservations")
class ReservationApiGateway {

	@Autowired
	private ReservationReader reservationReader;

	public List<DTOReservation> fallback(Long customerId) {
		return  Stream.of(new DTOReservation()).collect(Collectors.toList());
	}

	@HystrixCommand(fallbackMethod = "fallback")
	@ApiOperation(value = "Get reservations", notes = "Get reservations for customer.")
	@RequestMapping(value = "/customer/{customerId}", produces = "application/json; charset=UTF-8", method = RequestMethod.GET)
	public List<DTOReservation> getAllReservationsForCustomer(@PathVariable("customerId") Long customerId) {
		return reservationReader.getAllReservationsForCustomer(customerId);
	}

}
