package com.gopas.castleregistergtw.application.util;

import org.keycloak.KeycloakSecurityContext;
import org.keycloak.adapters.springsecurity.token.KeycloakAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;

public class SecurityContext {
	public static String getToken() {
		if (SecurityContextHolder.getContext().getAuthentication() instanceof KeycloakAuthenticationToken) {
			KeycloakAuthenticationToken securityContext = (KeycloakAuthenticationToken) SecurityContextHolder.getContext().getAuthentication();
			KeycloakSecurityContext keycloakSecurityContext = securityContext.getAccount().getKeycloakSecurityContext();
			return keycloakSecurityContext.getTokenString();
		} else {
			return "";
		}
	}

}
