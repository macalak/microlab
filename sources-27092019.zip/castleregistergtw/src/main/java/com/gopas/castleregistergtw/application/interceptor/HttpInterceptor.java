package com.gopas.castleregistergtw.application.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.gopas.castleregistergtw.application.util.SecurityContext;
import com.gopas.castleregistergtw.application.util.ThreadContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

@Service
public class HttpInterceptor extends HandlerInterceptorAdapter {

	static Logger logger = LoggerFactory.getLogger(HttpInterceptor.class);
	
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		// save token to thread local
		ThreadContext.setToken(SecurityContext.getToken());
		return super.preHandle(request, response, handler);
	}
}
