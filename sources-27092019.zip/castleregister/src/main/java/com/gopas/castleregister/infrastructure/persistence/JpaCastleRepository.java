package com.gopas.castleregister.infrastructure.persistence;

import com.gopas.castleregister.domain.model.Castle;
import com.gopas.castleregister.domain.model.CastleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public class JpaCastleRepository implements CastleRepository {

    @Autowired
    SpringDataCastleRepository springDataCastleRepository;


    @Override
    public Castle createCastle(Castle castle) {
        return springDataCastleRepository.save(castle);
    }

    @Override
    public void deleteCastle(UUID castleId) {
        springDataCastleRepository.deleteById(castleId);
    }

    @Override
    public List<Castle> findByName(String name) {
        return springDataCastleRepository.findByName(name);
    }

    @Override
    public Castle findById(UUID id) {
        return springDataCastleRepository.findById(id).orElse(null);
    }

    @Override
    public List<Castle> findByLocation(Double longitude, Double latitude, Double radius) {
        return springDataCastleRepository.findAll();
    }
}
