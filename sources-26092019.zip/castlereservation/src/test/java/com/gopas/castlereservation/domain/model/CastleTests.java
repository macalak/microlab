package com.gopas.castlereservation.domain.model;

import org.junit.Test;
import org.mockito.Mockito;

import java.util.UUID;

public class CastleTests {

    @Test
    public void addCastleRouteToCastle(){
        Castle testedSubject = new Castle(UUID.randomUUID(), "Test Castle");
        CastleRoute castleRoute = new CastleRoute(UUID.randomUUID(), "Nice Route", 500 );
        testedSubject.setCastleRouteRepository(Mockito.mock(CastleRouteRepository.class));
        testedSubject.setCastleRepository(Mockito.mock(CastleRepository.class));

        testedSubject.addRoute(castleRoute);
    }

    @Test
    public void addNullAsCastleRouteToCastle(){
        Castle testedSubject = new Castle(UUID.randomUUID(), "Test Castle");
        testedSubject.setCastleRouteRepository(Mockito.mock(CastleRouteRepository.class));
        testedSubject.setCastleRepository(Mockito.mock(CastleRepository.class));

        testedSubject.addRoute(null);
    }

}
