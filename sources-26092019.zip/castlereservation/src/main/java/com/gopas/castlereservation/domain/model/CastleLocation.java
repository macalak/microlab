package com.gopas.castlereservation.domain.model;

import javax.persistence.Embeddable;

@Embeddable
public class CastleLocation {
    private Double latitude;
    private Double longitude;

    public CastleLocation() {
    }

    public CastleLocation(Double latitude, Double longitude) {
        this.latitude = latitude;
        this.longitude = longitude;
    }

    public Double getLatitude() {
        return latitude;
    }

    public Double getLongitude() {
        return longitude;
    }

    @Override
    public String toString() {
        return "CastleLocation{" +
                "latitude=" + latitude +
                ", longitude=" + longitude +
                '}';
    }
}
