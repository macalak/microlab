package com.gopas.castlereservation.application;

import com.gopas.castlereservation.domain.model.Castle;
import com.gopas.castlereservation.domain.model.CastleRepository;
import com.gopas.castlereservation.domain.model.CastleRoute;
import com.gopas.castlereservation.domain.model.CastleRouteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
public class CastleService {
    @Autowired
    CastleRepository castleRepository;

    @Autowired
    CastleRouteRepository castleRouteRepository;

    @Transactional
    public void addRouteToCastle(CastleRoute castleRoute, Castle castle){
        castle.setCastleRepository(castleRepository);
        castle.setCastleRouteRepository(castleRouteRepository);
        castle.addRoute(castleRoute);
    }
}
