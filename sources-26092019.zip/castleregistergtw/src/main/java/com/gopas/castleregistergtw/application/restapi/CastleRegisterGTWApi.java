package com.gopas.castleregistergtw.application.restapi;

import com.gopas.castleregister.application.restapi.CastleDTO;
import com.gopas.castleregister.application.restapi.OwnerDTO;
import com.gopas.castleregistergtw.service.CastleRegisterFeignClient;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.netflix.ribbon.proxy.annotation.Hystrix;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

@RestController
@RequestMapping("/api-castleregister")
public class CastleRegisterGTWApi {
    private static final Logger LOG = LoggerFactory.getLogger(CastleRegisterGTWApi.class);

    @Autowired
    CastleRegisterFeignClient feignClient;

    @RequestMapping(consumes={"application/json"}, value="/owner", method= RequestMethod.POST )
    public ResponseEntity<Void> createOwner(@RequestBody @NotNull @Valid OwnerDTO ownerDTO){
        LOG.info("GTW: Creating Owner; {}", ownerDTO);
        return feignClient.createOwner(ownerDTO);
    }

    @HystrixCommand(fallbackMethod = "getOwnerFallback")
    @RequestMapping(produces={"application/json"}, value="/owner/{id}", method= RequestMethod.GET )
    public OwnerDTO getOwner(@PathVariable("id") String id){
        LOG.info("GTW: Get Owner by ID: {}", id);
        return feignClient.getOwner(id);
    }

    @RequestMapping(consumes={"application/json"}, value="/castle", method= RequestMethod.POST )
    public ResponseEntity<Void> createCastle(@RequestBody @NotNull @Valid CastleDTO castleDTO){
        LOG.info("GTW: Creating Castle: {}", castleDTO);
        return feignClient.createCastle(castleDTO);
    }

    private OwnerDTO getOwnerFallback(String id){
        OwnerDTO defaultOwner = new OwnerDTO();
        defaultOwner.id="default";
        defaultOwner.name="default owner";
        return defaultOwner;
    }
}
