package com.gopas.castleregister.domain.model;

public interface CastleRouteRepository {
    CastleRoute createCastleRoute(CastleRoute castleRoute);
}
