package com.gopas.castleregister.application.restapi;

public class CastleDTO {
    public String id;
    public String name;
    public String ownerId;
    public Double longitude;
    public Double latitude;
    public String description;
    public String address;
    public String webPage;
    public String foto;
    public Integer capacity;

    @Override
    public String toString() {
        return "CastleDTO{" +
                "id='" + id + '\'' +
                ", name='" + name + '\'' +
                ", ownerId='" + ownerId + '\'' +
                ", longitude=" + longitude +
                ", latitude=" + latitude +
                ", description='" + description + '\'' +
                ", address='" + address + '\'' +
                ", webPage='" + webPage + '\'' +
                ", foto='" + foto + '\'' +
                ", capacity=" + capacity +
                '}';
    }
}
